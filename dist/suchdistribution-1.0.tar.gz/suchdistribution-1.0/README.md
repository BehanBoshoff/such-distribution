#probability_distributions package

This is a package that does many wonderful things that normal people have no interest in whatsoever.
If you count yourself amongst them, then all you need to know is:

'Funny code big good.'

Enjoy!
