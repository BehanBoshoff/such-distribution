from setuptools import setup

setup(name='suchdistribution',
      version='1.0',
      description='All the things regarding Gaussian and Binomial distributions',
      packages=['suchdistribution'],
      author='Behan Boshoff',
      author_email = 'bhnboshoff@gmail.com',
      zip_safe=False)
